'use client'

import DashboardWorkspace from '@/src/components/dashboard/DashboardWorkspace'
import { SecurityGate } from '@/components/auth/SecurityGate'
import { FirebaseSession } from '@/components/auth/FirebaseSession'

export default function Page() {
  return (
    <SecurityGate>
      <FirebaseSession>
        <DashboardWorkspace onLogout={() => undefined} />
      </FirebaseSession>
    </SecurityGate>
  )
}
