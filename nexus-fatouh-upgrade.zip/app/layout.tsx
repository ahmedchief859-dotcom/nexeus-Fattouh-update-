import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'
import { I18nProvider } from '@/lib/i18n'
import { FirebaseSession } from '@/components/auth/FirebaseSession'

export const metadata: Metadata = {
  title: 'Nexora Business OS',
  description: 'Real-time SaaS and ERP operations workspace for sales, inventory, invoices, and business intelligence.',
  generator: 'Nexora Systems',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: 'white' },
    { media: '(prefers-color-scheme: dark)', color: 'black' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        <FirebaseSession>      <I18nProvider>{children}</I18nProvider></FirebaseSession>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
