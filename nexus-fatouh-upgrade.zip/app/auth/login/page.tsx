'use client'

import { FormEvent, useState } from 'react'
import Link from 'next/link'
import { GoogleAuthProvider, signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth'
import { firebaseAuth, firebaseDomainGuidance } from '@/lib/firebase'
import { SecurityGate } from '@/components/auth/SecurityGate'

export default function LoginPage() {
  const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [error, setError] = useState(''); const [loading, setLoading] = useState(false)
  function authMessage(error: unknown, fallback: string) {
    const code = typeof error === 'object' && error && 'code' in error ? String(error.code) : ''
    if (code === 'auth/unauthorized-domain') return `${fallback} This preview domain is not authorized in Firebase.`
    if (code === 'auth/network-request-failed') return 'Firebase is unreachable. Check your connection and try again.'
    if (code === 'auth/operation-not-allowed') return 'This sign-in method is not enabled in Firebase Authentication.'
    return fallback
  }
  async function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (!firebaseAuth) { setError('Authentication is unavailable in this browser build.'); return } setLoading(true); setError(''); try { await signInWithEmailAndPassword(firebaseAuth, email.trim(), password); window.location.assign('/') } catch (error) { setError(authMessage(error, 'Invalid email or password.')) } finally { setLoading(false) } }
  async function googleLogin() { if (!firebaseAuth) { setError('Authentication is unavailable in this browser build.'); return } setLoading(true); setError(''); try { await signInWithPopup(firebaseAuth, new GoogleAuthProvider()); window.location.assign('/') } catch (error) { setError(authMessage(error, 'Google sign-in is unavailable. Try email and password instead.')) } finally { setLoading(false) } }
  return <SecurityGate><main className="auth-shell"><div className="auth-card"><div className="brand-mark">N</div><p className="eyebrow">NEXORA BUSINESS OS</p><h1>Welcome back</h1><p className="auth-subtitle">Sign in to your command center.</p><button type="button" className="auth-google-button" onClick={googleLogin} disabled={loading}><span aria-hidden="true">G</span>{loading ? 'Connecting…' : 'Sign in with Google'}</button><div className="auth-divider"><span>or continue with email</span></div><form onSubmit={submit} className="auth-form"><label>Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" /></label><label>Password<input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="Your password" /></label>{error && <p className="auth-error" role="alert">{error}</p>}<button type="submit" disabled={loading}>{loading ? 'Signing in…' : 'Sign in to dashboard'}</button></form><p className="auth-footer">New to Nexora? <Link href="/auth/sign-up">Create an account</Link></p></div></main></SecurityGate>
}
