import { useState } from 'react';
import DeploymentGate from '@/components/auth/DeploymentGate';
import LoginCard from '@/components/auth/LoginCard';
import DashboardWorkspace from '@/components/dashboard/DashboardWorkspace';

type Stage = 'gate' | 'login' | 'dashboard';

export default function App() {
  const [stage, setStage] = useState<Stage>('gate');

  if (stage === 'gate') return <DeploymentGate onUnlock={() => setStage('login')} />;
  if (stage === 'login') return <LoginCard onLogin={() => setStage('dashboard')} />;
  return <DashboardWorkspace onLogout={() => setStage('gate')} />;
}
