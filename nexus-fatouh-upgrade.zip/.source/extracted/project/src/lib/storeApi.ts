import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export interface Branch {
  id: string;
  name: string;
  code: string;
  location: string;
  manager: string;
  status: 'active' | 'maintenance' | 'closed';
  created_at: string;
}

export interface StoreInventoryItem {
  id: string;
  branch_id: string;
  product_name: string;
  sku: string;
  category: string;
  stock: number;
  reorder_level: number;
  unit_price: number;
  updated_at: string;
}

export type InventoryStatus = 'in-stock' | 'low-stock' | 'out-of-stock';

export function itemStatus(item: StoreInventoryItem): InventoryStatus {
  if (item.stock <= 0) return 'out-of-stock';
  if (item.stock <= item.reorder_level) return 'low-stock';
  return 'in-stock';
}

export function useBranches() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('branches')
        .select('*')
        .order('created_at', { ascending: true });
      if (!active) return;
      if (error) setError(error.message);
      else setBranches(data as Branch[]);
      setLoading(false);
    })();
    return () => { active = false; };
  }, []);

  return { branches, loading, error };
}

export function useBranchInventory(branchId: string | null) {
  const [items, setItems] = useState<StoreInventoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refetch = useCallback(async () => {
    if (!branchId) { setItems([]); return; }
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from('store_inventory')
      .select('*')
      .eq('branch_id', branchId)
      .order('product_name', { ascending: true });
    if (error) setError(error.message);
    else setItems(data as StoreInventoryItem[]);
    setLoading(false);
  }, [branchId]);

  useEffect(() => { refetch(); }, [refetch]);

  return { items, loading, error, refetch };
}

export async function adjustStock(id: string, delta: number): Promise<{ error: string | null }> {
  const { data: current } = await supabase
    .from('store_inventory')
    .select('stock')
    .eq('id', id)
    .maybeSingle();
  if (!current) return { error: 'Item not found' };
  const next = Math.max(0, (current.stock as number) + delta);
  const { error } = await supabase
    .from('store_inventory')
    .update({ stock: next })
    .eq('id', id);
  return { error: error ? error.message : null };
}

export async function setStock(id: string, stock: number): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('store_inventory')
    .update({ stock: Math.max(0, stock) })
    .eq('id', id);
  return { error: error ? error.message : null };
}

export async function addInventoryItem(
  item: Omit<StoreInventoryItem, 'id' | 'updated_at' | 'branch_id'> & { branch_id: string }
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('store_inventory')
    .insert({
      branch_id: item.branch_id,
      product_name: item.product_name,
      sku: item.sku,
      category: item.category,
      stock: item.stock,
      reorder_level: item.reorder_level,
      unit_price: item.unit_price,
    });
  return { error: error ? error.message : null };
}

export async function deleteInventoryItem(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from('store_inventory')
    .delete()
    .eq('id', id);
  return { error: error ? error.message : null };
}

export async function transferStock(
  itemId: string,
  fromBranchId: string,
  toBranchId: string,
  quantity: number
): Promise<{ error: string | null }> {
  const { data: item } = await supabase
    .from('store_inventory')
    .select('*')
    .eq('id', itemId)
    .maybeSingle();
  if (!item) return { error: 'Source item not found' };
  if (item.stock < quantity) return { error: 'Insufficient stock to transfer' };

  const newSourceStock = item.stock - quantity;

  const { data: dest } = await supabase
    .from('store_inventory')
    .select('id, stock')
    .eq('branch_id', toBranchId)
    .eq('sku', item.sku)
    .maybeSingle();

  if (dest) {
    const { error: u1 } = await supabase
      .from('store_inventory')
      .update({ stock: (dest.stock as number) + quantity })
      .eq('id', (dest as StoreInventoryItem).id);
    if (u1) return { error: u1.message };
  } else {
    const { error: i1 } = await supabase
      .from('store_inventory')
      .insert({
        branch_id: toBranchId,
        product_name: item.product_name,
        sku: item.sku,
        category: item.category,
        stock: quantity,
        reorder_level: item.reorder_level,
        unit_price: item.unit_price,
      });
    if (i1) return { error: i1.message };
  }

  const { error: u2 } = await supabase
    .from('store_inventory')
    .update({ stock: newSourceStock })
    .eq('id', itemId);
  return { error: u2 ? u2.message : null };
}
