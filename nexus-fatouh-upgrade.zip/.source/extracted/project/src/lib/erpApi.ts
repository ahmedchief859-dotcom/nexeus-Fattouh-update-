import { supabase } from '@/lib/supabase';

export interface Transaction {
  id: string;
  branch_id: string | null;
  product_name: string;
  sku: string;
  quantity: number;
  unit_price: number;
  total: number;
  status: string;
  created_at: string;
}

export interface InvoiceLineItem {
  name: string;
  qty: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  client_name: string;
  client_email: string;
  line_items: InvoiceLineItem[];
  subtotal: number;
  vat_rate: number;
  vat_amount: number;
  total: number;
  currency: string;
  status: string;
  created_at: string;
}

export interface UsageMetric {
  id: string;
  metric: string;
  used: number;
  limit_value: number;
  updated_at: string;
}

// ---------- Transactions ----------
export async function fetchTransactions(branchId?: string): Promise<{ data: Transaction[] | null; error: string | null }> {
  let q = supabase.from('transactions').select('*').order('created_at', { ascending: false }).limit(50);
  if (branchId) q = q.eq('branch_id', branchId);
  const { data, error } = await q;
  return { data: data as Transaction[] | null, error: error ? error.message : null };
}

export async function addTransaction(t: {
  branch_id?: string | null; product_name: string; sku: string;
  quantity: number; unit_price: number; total: number; status?: string;
}): Promise<{ error: string | null }> {
  const { error } = await supabase.from('transactions').insert({
    branch_id: t.branch_id ?? null,
    product_name: t.product_name,
    sku: t.sku,
    quantity: t.quantity,
    unit_price: t.unit_price,
    total: t.total,
    status: t.status ?? 'completed',
  });
  return { error: error ? error.message : null };
}

// ---------- Invoices ----------
export async function fetchInvoices(): Promise<{ data: Invoice[] | null; error: string | null }> {
  const { data, error } = await supabase.from('invoices').select('*').order('created_at', { ascending: false });
  return { data: data as Invoice[] | null, error: error ? error.message : null };
}

export async function createInvoice(inv: {
  client_name: string; client_email: string; line_items: InvoiceLineItem[];
  subtotal: number; vat_rate: number; vat_amount: number; total: number; currency: string;
}): Promise<{ id: string | null; error: string | null }> {
  const { data: last } = await supabase
    .from('invoices').select('invoice_number').order('created_at', { ascending: false }).limit(1).maybeSingle();
  let num = 1;
  if (last?.invoice_number) {
    const m = (last.invoice_number as string).match(/(\d+)$/);
    if (m) num = parseInt(m[1], 10) + 1;
  }
  const invoice_number = `INV-${String(num).padStart(4, '0')}`;
  const { data, error } = await supabase.from('invoices').insert({
    invoice_number, client_name: inv.client_name, client_email: inv.client_email,
    line_items: inv.line_items, subtotal: inv.subtotal, vat_rate: inv.vat_rate,
    vat_amount: inv.vat_amount, total: inv.total, currency: inv.currency, status: 'draft',
  }).select('id').maybeSingle();
  return { id: data?.id ?? null, error: error ? error.message : null };
}

export async function updateInvoiceStatus(id: string, status: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('invoices').update({ status }).eq('id', id);
  return { error: error ? error.message : null };
}

export async function deleteInvoice(id: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('invoices').delete().eq('id', id);
  return { error: error ? error.message : null };
}

// ---------- Subscription Usage ----------
export async function fetchUsage(): Promise<{ data: UsageMetric[] | null; error: string | null }> {
  const { data, error } = await supabase.from('subscription_usage').select('*').order('metric');
  return { data: data as UsageMetric[] | null, error: error ? error.message : null };
}

// ---------- Analytics helpers (voice + forecasting) ----------
export interface DailyRevenue { date: string; total: number; }

export async function fetchDailyRevenue(days = 7): Promise<DailyRevenue[]> {
  const { data } = await supabase.from('transactions').select('total, created_at').eq('status', 'completed');
  if (!data) return [];
  const map = new Map<string, number>();
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    map.set(d.toISOString().slice(0, 10), 0);
  }
  (data as { total: number; created_at: string }[]).forEach((r) => {
    const key = new Date(r.created_at).toISOString().slice(0, 10);
    if (map.has(key)) map.set(key, (map.get(key) ?? 0) + Number(r.total));
  });
  return Array.from(map.entries()).map(([date, total]) => ({ date, total }));
}

export async function fetchTopProducts(limit = 5): Promise<{ product_name: string; qty: number; revenue: number }[]> {
  const { data } = await supabase.from('transactions').select('product_name, quantity, total').eq('status', 'completed');
  if (!data) return [];
  const map = new Map<string, { product_name: string; qty: number; revenue: number }>();
  (data as { product_name: string; quantity: number; total: number }[]).forEach((r) => {
    const ex = map.get(r.product_name) ?? { product_name: r.product_name, qty: 0, revenue: 0 };
    ex.qty += r.quantity; ex.revenue += Number(r.total);
    map.set(r.product_name, ex);
  });
  return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue).slice(0, limit);
}

// ---------- Forecasting ----------
export function forecastNext(history: number[], days: number): number[] {
  if (history.length < 3) return Array(days).fill(history[history.length - 1] ?? 0);
  const n = history.length;
  const smaWindow = Math.min(3, n);
  const sma: number[] = [];
  for (let i = smaWindow - 1; i < n; i++) {
    sma.push(history.slice(i - smaWindow + 1, i + 1).reduce((a, b) => a + b, 0) / smaWindow);
  }
  const trend = sma.length >= 2 ? (sma[sma.length - 1] - sma[0]) / (sma.length - 1) : 0;
  const last = history[n - 1];
  const seasonal = n >= 7 ? (history[n - 1] - history[n - 8]) / 7 : 0;
  const out: number[] = [];
  for (let i = 1; i <= days; i++) {
    const projected = last + trend * i + seasonal * 0.3;
    out.push(Math.max(0, Math.round(projected)));
  }
  return out;
}
