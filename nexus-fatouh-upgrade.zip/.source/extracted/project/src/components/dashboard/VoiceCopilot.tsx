import { useEffect, useRef, useState, useCallback } from 'react';
import { Sparkles, X, Mic, MicOff, Send, Volume2, VolumeX, Loader2, Radio } from 'lucide-react';
import { voiceEngine, parseCommand, type ParsedCommand } from '@/lib/voiceEngine';

export interface VoiceContext {
  navigate: (target: string) => void;
  toast: (msg: string, ok?: boolean) => void;
}

interface Msg { id: number; role: 'user' | 'ai'; text: string; spoken?: boolean; }

let msgId = 0;

export default function VoiceCopilot({ open, onClose, ctx }: { open: boolean; onClose: () => void; ctx: VoiceContext }) {
  const [messages, setMessages] = useState<Msg[]>([
    { id: ++msgId, role: 'ai', text: "Hi Ahmed! I'm your NEXORA Cognitive Voice Co-Pilot. Tap the mic and try: \"Open store management\", \"What's our highest selling item?\", or \"Add 50 units of bottled water to Downtown Flagship\"." },
  ]);
  const [input, setInput] = useState('');
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [ttsOn, setTtsOn] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  // Audio visualizer animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx2d = canvas.getContext('2d');
    if (!ctx2d) return;
    const dpr = window.devicePixelRatio || 1;
    const resize = () => {
      canvas.width = canvas.clientWidth * dpr;
      canvas.height = canvas.clientHeight * dpr;
    };
    resize();

    const render = () => {
      const w = canvas.width, h = canvas.height;
      ctx2d.clearRect(0, 0, w, h);
      const t = Date.now() / 1000;
      const bars = 48;
      const gap = 4 * dpr;
      const barW = (w - gap * (bars - 1)) / bars;
      for (let i = 0; i < bars; i++) {
        let amp: number;
        if (listening) {
          amp = (Math.sin(t * 6 + i * 0.4) * 0.4 + Math.sin(t * 11 + i * 0.7) * 0.3 + 0.5) * h * 0.45;
        } else if (speaking) {
          amp = (Math.sin(t * 8 + i * 0.5) * 0.3 + Math.sin(t * 14 + i * 0.3) * 0.2 + 0.4) * h * 0.35;
        } else {
          amp = (Math.sin(t * 1.5 + i * 0.3) * 0.1 + 0.12) * h * 0.15;
        }
        const x = i * (barW + gap);
        const y = (h - amp) / 2;
        const grad = ctx2d.createLinearGradient(0, y, 0, y + amp);
        const baseColor = listening ? '#7ee8e8' : speaking ? '#a78bfa' : '#7ee8e8';
        grad.addColorStop(0, baseColor);
        grad.addColorStop(1, `${baseColor}22`);
        ctx2d.fillStyle = grad;
        const r = Math.min(barW / 2, 3 * dpr);
        ctx2d.beginPath();
        ctx2d.moveTo(x + r, y);
        ctx2d.lineTo(x + barW - r, y);
        ctx2d.quadraticCurveTo(x + barW, y, x + barW, y + r);
        ctx2d.lineTo(x + barW, y + amp - r);
        ctx2d.quadraticCurveTo(x + barW, y + amp, x + barW - r, y + amp);
        ctx2d.lineTo(x + r, y + amp);
        ctx2d.quadraticCurveTo(x, y + amp, x, y + amp - r);
        ctx2d.lineTo(x, y + r);
        ctx2d.quadraticCurveTo(x, y, x + r, y);
        ctx2d.fill();
      }
      rafRef.current = requestAnimationFrame(render);
    };
    render();
    window.addEventListener('resize', resize);
    return () => { cancelAnimationFrame(rafRef.current); window.removeEventListener('resize', resize); };
  }, [listening, speaking]);

  const addMsg = (role: 'user' | 'ai', text: string) => {
    setMessages((m) => [...m, { id: ++msgId, role, text }]);
  };

  const speak = useCallback((text: string) => {
    if (!ttsOn || !voiceEngine.ttsSupported) return;
    setSpeaking(true);
    voiceEngine.speak(text, () => setSpeaking(false));
  }, [ttsOn]);

  const executeCommand = useCallback(async (cmd: ParsedCommand): Promise<string> => {
    switch (cmd.intent) {
      case 'navigate': {
        ctx.navigate(cmd.args.target);
        return `Opening ${cmd.args.target === 'store' ? 'Store Management' : cmd.args.target} now.`;
      }
      case 'top_products': {
        const { fetchTopProducts } = await import('@/lib/erpApi');
        const tops = await fetchTopProducts(5);
        if (tops.length === 0) return "I couldn't find any completed transactions yet.";
        const top = tops[0];
        return `Your highest selling item is ${top.product_name} with ${top.qty} units sold, generating $${top.revenue.toFixed(2)} in revenue.`;
      }
      case 'revenue': {
        const { fetchDailyRevenue } = await import('@/lib/erpApi');
        const daily = await fetchDailyRevenue(7);
        const total = daily.reduce((s, d) => s + d.total, 0);
        return `Total revenue over the last 7 days is $${total.toFixed(2)}.`;
      }
      case 'low_stock': {
        const { useBranchInventory } = await import('@/lib/storeApi');
        const { fetchBranches } = await import('@/lib/storeApi');
        // Use a simple direct query instead
        const { supabase } = await import('@/lib/supabase');
        const { data } = await supabase.from('store_inventory').select('product_name, stock, reorder_level, branch_id').lte('stock', 10);
        const low = (data ?? []).filter((i: any) => i.stock <= i.reorder_level);
        if (low.length === 0) return "No low stock items detected. All inventory is healthy.";
        const names = low.slice(0, 5).map((i: any) => i.product_name).join(', ');
        return `I found ${low.length} low or out-of-stock items: ${names}. Consider restocking soon.`;
      }
      case 'add_stock': {
        const { supabase } = await import('@/lib/supabase');
        const { data: branches } = await supabase.from('branches').select('id, name');
        const branch = (branches ?? []).find((b: any) =>
          b.name.toLowerCase().includes(cmd.args.branch.toLowerCase()) ||
          cmd.args.branch.toLowerCase().includes(b.name.toLowerCase().split(' ')[0]));
        if (!branch) return `I couldn't find a branch matching "${cmd.args.branch}".`;
        const qty = parseInt(cmd.args.product ? cmd.args.quantity : cmd.args.quantity, 10);
        const productName = cmd.args.product;
        const { data: existing } = await supabase
          .from('store_inventory').select('id, stock').eq('branch_id', branch.id).ilike('product_name', `%${productName}%`).maybeSingle();
        if (existing) {
          const newStock = (existing.stock as number) + qty;
          await supabase.from('store_inventory').update({ stock: newStock }).eq('id', existing.id);
          ctx.toast(`Added ${qty} units of ${productName} to ${branch.name}`, true);
          return `Done. Added ${qty} units of ${productName} to ${branch.name}. New stock level is ${newStock} units.`;
        }
        await supabase.from('store_inventory').insert({
          branch_id: branch.id, product_name: productName, sku: `SN-${Date.now().toString().slice(-5)}`,
          category: 'General', stock: qty, reorder_level: 10, unit_price: 0,
        });
        ctx.toast(`Added ${qty} units of ${productName} to ${branch.name}`, true);
        return `Created ${productName} in ${branch.name} with ${qty} units.`;
      }
      case 'create_invoice': {
        ctx.navigate('invoices');
        return "Opening the invoice generator. You can fill in the client details and line items there.";
      }
      case 'health': {
        const { fetchDailyRevenue } = await import('@/lib/erpApi');
        const daily = await fetchDailyRevenue(7);
        const avg = daily.length ? daily.reduce((s, d) => s + d.total, 0) / daily.length : 0;
        if (avg > 200) return "Business health is Optimal. Average daily revenue is strong at $" + avg.toFixed(0) + ".";
        if (avg > 50) return "Business health is Warning. Average daily revenue is $" + avg.toFixed(0) + " — consider boosting sales.";
        return "Business health is Critical. Average daily revenue is low at $" + avg.toFixed(0) + ".";
      }
      case 'list_branches': {
        const { supabase } = await import('@/lib/supabase');
        const { data } = await supabase.from('branches').select('name, code, status');
        const list = (data ?? []).map((b: any) => b.name).join(', ');
        return `You have ${(data ?? []).length} branches: ${list}.`;
      }
      default:
        return "I can help with navigation, inventory, sales analytics, invoices, and business health. Try saying \"open store management\" or \"what's our highest selling item?\".";
    }
  }, [ctx]);

  const handleInput = async (text: string) => {
    if (!text.trim()) return;
    addMsg('user', text);
    setInput('');
    setThinking(true);
    const cmd = parseCommand(text);
    const reply = await executeCommand(cmd);
    setThinking(false);
    addMsg('ai', reply);
    speak(reply);
  };

  const toggleListen = () => {
    if (listening) { voiceEngine.stop(); setListening(false); return; }
    setListening(true);
    voiceEngine.start(
      (transcript, isFinal) => { setInput(transcript); if (isFinal) { setListening(false); handleInput(transcript); } },
      () => setListening(false),
    );
  };

  const suggestions = [
    'Open store management',
    "What's our highest selling item?",
    'Add 20 units of Cold Brew to Downtown',
    'Show business health',
  ];

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 animate-fade-in" onClick={onClose} />}
      <div className={`fixed top-0 right-0 h-screen w-full max-w-md z-50 glass-strong border-l border-white/10 flex flex-col transition-transform duration-300 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 h-16 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="relative w-9 h-9 rounded-xl bg-gradient-to-br from-nexora-accent to-purple-400 flex items-center justify-center">
              {speaking && <div className="absolute inset-0 rounded-xl bg-nexora-accent/40 animate-ping" />}
              <Sparkles className="w-5 h-5 text-nexora-deep" />
            </div>
            <div>
              <h3 className="font-display font-semibold text-white text-sm">NEXORA Cognitive Co-Pilot</h3>
              <p className="text-[10px] flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${listening ? 'bg-nexora-accent animate-pulse' : speaking ? 'bg-purple-400 animate-pulse' : 'bg-green-400'}`} />
                <span className="text-white/40">{listening ? 'Listening...' : speaking ? 'Speaking...' : 'Ready'}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => { setTtsOn((v) => !v); if (speaking) { voiceEngine.stopSpeaking(); setSpeaking(false); } }} className="p-2 rounded-lg hover:bg-white/10 text-white/50 hover:text-white transition-colors" title={ttsOn ? 'Mute voice' : 'Unmute voice'}>
              {ttsOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10 text-white/50 hover:text-white"><X className="w-5 h-5" /></button>
          </div>
        </div>

        {/* Audio visualizer */}
        <div className="px-5 pt-4 pb-3 border-b border-white/5">
          <div className="relative h-20 rounded-xl glass overflow-hidden">
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
            {listening && (
              <div className="absolute top-2 left-3 flex items-center gap-1.5 text-[10px] text-nexora-accent font-medium">
                <Radio className="w-3 h-3 animate-pulse" /> LIVE
              </div>
            )}
          </div>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {messages.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-up`}>
              <div className={`max-w-[85%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                m.role === 'user' ? 'bg-nexora-accent text-nexora-deep rounded-br-sm' : 'glass text-white/85 rounded-bl-sm'
              }`}>
                {m.text}
                {m.role === 'ai' && speaking && ttsOn && (
                  <Volume2 className="inline-block w-3 h-3 ml-1.5 text-nexora-accent animate-pulse" />
                )}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex justify-start animate-slide-up">
              <div className="glass px-4 py-3 rounded-2xl rounded-bl-sm flex items-center gap-2 text-white/50 text-sm">
                <Loader2 className="w-4 h-4 animate-spin" /> Analyzing...
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        <div className="px-5 pb-3 flex flex-wrap gap-2">
          {suggestions.map((s) => (
            <button key={s} onClick={() => handleInput(s)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs text-white/60 hover:text-white hover:border-nexora-accent/30 transition-all">
              {s}
            </button>
          ))}
        </div>

        {/* Input + mic */}
        <form onSubmit={(e) => { e.preventDefault(); handleInput(input); }} className="px-5 pb-5 pt-2 border-t border-white/5 flex items-center gap-2">
          <button type="button" onClick={toggleListen} className={`p-3 rounded-xl transition-all shrink-0 ${listening ? 'bg-red-400/20 text-red-300 border border-red-400/30' : 'bg-nexora-accent/15 text-nexora-accent border border-nexora-accent/20 hover:bg-nexora-accent/25'}`}>
            {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={listening ? 'Listening...' : 'Type or speak a command...'}
            className="flex-1 px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-sm text-white placeholder-white/30 outline-none focus:border-nexora-accent/40"
          />
          <button type="submit" className="p-3 rounded-xl bg-nexora-accent text-nexora-deep hover:bg-nexora-accent-2 transition-colors shrink-0">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </>
  );
}
