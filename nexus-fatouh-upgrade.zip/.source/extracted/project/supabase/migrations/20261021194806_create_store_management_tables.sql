/*
# Store Management: branches + inventory allocation

1. Overview
This migration creates the data layer for the Store Management workspace.
It introduces two tables: `branches` (the physical store locations the
manager can switch between) and `store_inventory` (the per-branch stock of
individual products). Together they power branch switching and inventory
allocation in the dashboard.

2. New Tables

  branches
  - id          (uuid, primary key)
  - name        (text, not null)        — display name e.g. "Downtown Flagship"
  - code        (text, unique, not null) — short code e.g. "DT-01"
  - location    (text)                  — address / area description
  - manager     (text)                  — manager name shown in UI
  - status      (text, not null, default 'active') — 'active' | 'maintenance' | 'closed'
  - created_at  (timestamptz, default now())

  store_inventory
  - id            (uuid, primary key)
  - branch_id     (uuid, foreign key -> branches.id ON DELETE CASCADE)
  - product_name  (text, not null)
  - sku           (text, not null)      — stock-keeping unit code
  - category      (text, not null)      — e.g. "Drinks", "Food Items"
  - stock         (integer, not null, default 0)     — current units on hand
  - reorder_level (integer, not null, default 10)    — threshold for low-stock alert
  - unit_price    (numeric(10,2), not null, default 0) — selling price per unit
  - updated_at    (timestamptz, default now())
  - UNIQUE (branch_id, sku) so the same product cannot be listed twice per branch

3. Indexes
  - store_inventory_branch_id_idx for fast per-branch listing
  - store_inventory_branch_id_sku_key unique constraint

4. Security (RLS)
  This dashboard is single-tenant (visual login gate only, no Supabase auth).
  Policies therefore use `TO anon, authenticated` so the anon-key frontend
  can read and write its own data. The data is intentionally shared/public
  within the deployment.

5. Seed Data
  - 3 branches (Downtown Flagship, Riverside Mall, Airport Express)
  - 7 inventory items per branch (21 rows) with varied stock levels,
    categories, and reorder thresholds so the UI shows realistic content
    including some low-stock items.

6. Important Notes
  - Re-running this migration is safe: tables use IF NOT EXISTS, policies are
    dropped before re-created, and the seed block is guarded by an existence
    check so rows are not duplicated.
*/

CREATE TABLE IF NOT EXISTS branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE NOT NULL,
  location text,
  manager text,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS store_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
  product_name text NOT NULL,
  sku text NOT NULL,
  category text NOT NULL,
  stock integer NOT NULL DEFAULT 0,
  reorder_level integer NOT NULL DEFAULT 10,
  unit_price numeric(10,2) NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE (branch_id, sku)
);

CREATE INDEX IF NOT EXISTS store_inventory_branch_id_idx ON store_inventory(branch_id);

ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE store_inventory ENABLE ROW LEVEL SECURITY;

-- branches policies (single-tenant: anon + authenticated)
DROP POLICY IF EXISTS "branches_select_all" ON branches;
CREATE POLICY "branches_select_all" ON branches FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "branches_insert_all" ON branches;
CREATE POLICY "branches_insert_all" ON branches FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "branches_update_all" ON branches;
CREATE POLICY "branches_update_all" ON branches FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "branches_delete_all" ON branches;
CREATE POLICY "branches_delete_all" ON branches FOR DELETE
  TO anon, authenticated USING (true);

-- store_inventory policies (single-tenant: anon + authenticated)
DROP POLICY IF EXISTS "inventory_select_all" ON store_inventory;
CREATE POLICY "inventory_select_all" ON store_inventory FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "inventory_insert_all" ON store_inventory;
CREATE POLICY "inventory_insert_all" ON store_inventory FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "inventory_update_all" ON store_inventory;
CREATE POLICY "inventory_update_all" ON store_inventory FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "inventory_delete_all" ON store_inventory;
CREATE POLICY "inventory_delete_all" ON store_inventory FOR DELETE
  TO anon, authenticated USING (true);

-- updated_at trigger for store_inventory
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS store_inventory_touch ON store_inventory;
CREATE TRIGGER store_inventory_touch
  BEFORE UPDATE ON store_inventory
  FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Seed branches (guarded)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM branches LIMIT 1) THEN
    INSERT INTO branches (name, code, location, manager, status) VALUES
      ('Downtown Flagship', 'DT-01', '12 Tahrir Square, Cairo', 'Ahmed Mohamed', 'active'),
      ('Riverside Mall', 'RV-02', 'Mall of Egypt, 6th October City', 'Lina Hassan', 'active'),
      ('Airport Express', 'AP-03', 'Cairo Intl Airport, Terminal 3', 'Omar Farouk', 'maintenance');
  END IF;
END $$;

-- Seed inventory (guarded)
DO $$
DECLARE
  dt uuid; rv uuid; ap uuid;
BEGIN
  SELECT id INTO dt FROM branches WHERE code = 'DT-01';
  SELECT id INTO rv FROM branches WHERE code = 'RV-02';
  SELECT id INTO ap FROM branches WHERE code = 'AP-03';

  IF NOT EXISTS (SELECT 1 FROM store_inventory LIMIT 1) THEN
    -- Downtown Flagship
    INSERT INTO store_inventory (branch_id, product_name, sku, category, stock, reorder_level, unit_price) VALUES
      (dt, 'Organic Cold Brew',  'SN-781', 'Drinks',            320, 50, 10.00),
      (dt, 'Artisan Sourdough',  'SN-782', 'Food Items',        145, 40, 8.00),
      (dt, 'Aloe Vera Serum',    'SN-783', 'Personal Products',  76, 30, 20.00),
      (dt, 'Eco Tote Bag',       'SN-784', 'Supplies',          410, 60, 5.00),
      (dt, 'Matcha Latte Mix',   'SN-785', 'Drinks',             28, 40, 10.00),
      (dt, 'Organic Milk 1L',    'SN-786', 'Food Items',          8, 25, 3.50),
      (dt, 'Bamboo Cutlery Set', 'SN-787', 'Supplies',           95, 20, 12.00);

    -- Riverside Mall
    INSERT INTO store_inventory (branch_id, product_name, sku, category, stock, reorder_level, unit_price) VALUES
      (rv, 'Organic Cold Brew',  'SN-781', 'Drinks',            180, 50, 10.00),
      (rv, 'Artisan Sourdough',  'SN-782', 'Food Items',         62, 40, 8.00),
      (rv, 'Aloe Vera Serum',    'SN-783', 'Personal Products', 140, 30, 20.00),
      (rv, 'Eco Tote Bag',       'SN-784', 'Supplies',          240, 60, 5.00),
      (rv, 'Matcha Latte Mix',   'SN-785', 'Drinks',             55, 40, 10.00),
      (rv, 'Organic Milk 1L',    'SN-786', 'Food Items',         31, 25, 3.50),
      (rv, 'Bamboo Cutlery Set', 'SN-787', 'Supplies',           12, 20, 12.00);

    -- Airport Express
    INSERT INTO store_inventory (branch_id, product_name, sku, category, stock, reorder_level, unit_price) VALUES
      (ap, 'Organic Cold Brew',  'SN-781', 'Drinks',             44, 50, 12.00),
      (ap, 'Artisan Sourdough',  'SN-782', 'Food Items',         20, 40, 9.00),
      (ap, 'Aloe Vera Serum',    'SN-783', 'Personal Products',  18, 30, 22.00),
      (ap, 'Eco Tote Bag',       'SN-784', 'Supplies',           88, 60, 6.00),
      (ap, 'Matcha Latte Mix',   'SN-785', 'Drinks',             15, 40, 12.00),
      (ap, 'Organic Milk 1L',    'SN-786', 'Food Items',          5, 25, 4.00),
      (ap, 'Bamboo Cutlery Set', 'SN-787', 'Supplies',           33, 20, 14.00);
  END IF;
END $$;
