/*
# NEXORA ERP data layer: transactions, invoices, subscription usage

1. Overview
Extends the Store Management schema with three new tables that power the
voice co-pilot analytics, the PDF billing engine, and the subscription
lifecycle dashboard.

2. New Tables

  transactions
  - id           (uuid PK)
  - branch_id    (uuid FK -> branches.id ON DELETE SET NULL)
  - product_name (text)            — snapshot of product sold
  - sku          (text)            — snapshot of SKU
  - quantity     (integer, default 1)
  - unit_price   (numeric(10,2), default 0)
  - total        (numeric(12,2), default 0)  — quantity * unit_price
  - status       (text, default 'completed') — completed|pending|refunded
  - created_at   (timestamptz)

  invoices
  - id            (uuid PK)
  - invoice_number (text, unique)  — human-readable INV-0001
  - client_name   (text)
  - client_email  (text)
  - line_items    (jsonb)          — [{name, qty, unitPrice, total}]
  - subtotal      (numeric(12,2))
  - vat_rate      (numeric(5,2), default 15)  — percentage
  - vat_amount    (numeric(12,2), default 0)
  - total         (numeric(12,2), default 0)
  - currency      (text, default 'USD')
  - status        (text, default 'draft') — draft|sent|paid
  - created_at    (timestamptz)

  subscription_usage
  - id            (uuid PK)
  - metric        (text, unique)  — api_calls|storage_gb|seats|bandwidth_gb
  - used          (numeric(12,2), default 0)
  - limit_value   (numeric(12,2), default 0)
  - updated_at    (timestamptz)

3. Indexes
  - transactions_branch_id_idx, transactions_created_at_idx
  - invoices_created_at_idx, invoices_status_idx

4. Security (RLS)
  Single-tenant dashboard (visual login gate only). Policies use
  TO anon, authenticated so the anon-key frontend can CRUD its own data.

5. Seed Data
  - 12 transactions across branches (last 7 days) for forecasting + voice queries
  - 3 invoices (draft, sent, paid)
  - 4 subscription_usage rows with realistic meter values
*/

CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  product_name text,
  sku text,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text UNIQUE NOT NULL,
  client_name text NOT NULL,
  client_email text,
  line_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(12,2) NOT NULL DEFAULT 0,
  vat_rate numeric(5,2) NOT NULL DEFAULT 15,
  vat_amount numeric(12,2) NOT NULL DEFAULT 0,
  total numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'USD',
  status text NOT NULL DEFAULT 'draft',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS subscription_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric text UNIQUE NOT NULL,
  used numeric(12,2) NOT NULL DEFAULT 0,
  limit_value numeric(12,2) NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS transactions_branch_id_idx ON transactions(branch_id);
CREATE INDEX IF NOT EXISTS transactions_created_at_idx ON transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS invoices_created_at_idx ON invoices(created_at DESC);
CREATE INDEX IF NOT EXISTS invoices_status_idx ON invoices(status);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_usage ENABLE ROW LEVEL SECURITY;

-- transactions policies
DROP POLICY IF EXISTS "tx_select_all" ON transactions;
CREATE POLICY "tx_select_all" ON transactions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "tx_insert_all" ON transactions;
CREATE POLICY "tx_insert_all" ON transactions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "tx_update_all" ON transactions;
CREATE POLICY "tx_update_all" ON transactions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "tx_delete_all" ON transactions;
CREATE POLICY "tx_delete_all" ON transactions FOR DELETE TO anon, authenticated USING (true);

-- invoices policies
DROP POLICY IF EXISTS "inv_select_all" ON invoices;
CREATE POLICY "inv_select_all" ON invoices FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "inv_insert_all" ON invoices;
CREATE POLICY "inv_insert_all" ON invoices FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "inv_update_all" ON invoices;
CREATE POLICY "inv_update_all" ON invoices FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "inv_delete_all" ON invoices;
CREATE POLICY "inv_delete_all" ON invoices FOR DELETE TO anon, authenticated USING (true);

-- subscription_usage policies
DROP POLICY IF EXISTS "usage_select_all" ON subscription_usage;
CREATE POLICY "usage_select_all" ON subscription_usage FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "usage_update_all" ON subscription_usage;
CREATE POLICY "usage_update_all" ON subscription_usage FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Seed transactions (guarded)
DO $$
DECLARE dt uuid; rv uuid; ap uuid;
BEGIN
  SELECT id INTO dt FROM branches WHERE code = 'DT-01';
  SELECT id INTO rv FROM branches WHERE code = 'RV-02';
  SELECT id INTO ap FROM branches WHERE code = 'AP-03';
  IF NOT EXISTS (SELECT 1 FROM transactions LIMIT 1) THEN
    INSERT INTO transactions (branch_id, product_name, sku, quantity, unit_price, total, status, created_at) VALUES
      (dt, 'Organic Cold Brew',  'SN-781', 12, 10.00, 120.00,  'completed', now() - interval '6 days'),
      (dt, 'Artisan Sourdough',  'SN-782',  8,  8.00,  64.00,  'completed', now() - interval '6 days'),
      (dt, 'Aloe Vera Serum',    'SN-783',  5, 20.00, 100.00,  'completed', now() - interval '5 days'),
      (rv, 'Eco Tote Bag',       'SN-784', 30,  5.00, 150.00,  'completed', now() - interval '5 days'),
      (rv, 'Matcha Latte Mix',   'SN-785',  9, 10.00,  90.00,  'completed', now() - interval '4 days'),
      (dt, 'Organic Cold Brew',  'SN-781', 18, 10.00, 180.00,  'completed', now() - interval '4 days'),
      (ap, 'Bamboo Cutlery Set', 'SN-787',  6, 14.00,  84.00,  'completed', now() - interval '3 days'),
      (rv, 'Aloe Vera Serum',    'SN-783',  7, 20.00, 140.00,  'completed', now() - interval '3 days'),
      (dt, 'Artisan Sourdough',  'SN-782', 11,  8.00,  88.00,  'completed', now() - interval '2 days'),
      (dt, 'Organic Milk 1L',    'SN-786', 24,  3.50,  84.00,  'completed', now() - interval '2 days'),
      (rv, 'Organic Cold Brew',  'SN-781', 14, 10.00, 140.00,  'completed', now() - interval '1 day'),
      (dt, 'Aloe Vera Serum',    'SN-783',  3, 20.00,  60.00,  'pending',   now() - interval '1 day');
  END IF;
END $$;

-- Seed invoices (guarded)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM invoices LIMIT 1) THEN
    INSERT INTO invoices (invoice_number, client_name, client_email, line_items, subtotal, vat_rate, vat_amount, total, currency, status) VALUES
      ('INV-0001', 'Sarah Khalil', 'sarah@example.com',
        '[{"name":"Organic Cold Brew","qty":12,"unitPrice":10,"total":120},{"name":"Artisan Sourdough","qty":8,"unitPrice":8,"total":64}]'::jsonb,
        184.00, 15, 27.60, 211.60, 'USD', 'paid'),
      ('INV-0002', 'Mohamed Ali', 'm.ali@example.com',
        '[{"name":"Aloe Vera Serum","qty":5,"unitPrice":20,"total":100},{"name":"Eco Tote Bag","qty":10,"unitPrice":5,"total":50}]'::jsonb,
        150.00, 15, 22.50, 172.50, 'USD', 'sent'),
      ('INV-0003', 'Lina Hassan', 'lina@example.com',
        '[{"name":"Matcha Latte Mix","qty":9,"unitPrice":10,"total":90}]'::jsonb,
        90.00, 15, 13.50, 103.50, 'EUR', 'draft');
  END IF;
END $$;

-- Seed subscription usage (guarded)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM subscription_usage LIMIT 1) THEN
    INSERT INTO subscription_usage (metric, used, limit_value) VALUES
      ('api_calls', 842300, 1000000),
      ('storage_gb', 42.6, 64),
      ('seats', 18, 25),
      ('bandwidth_gb', 312.4, 500);
  END IF;
END $$;
