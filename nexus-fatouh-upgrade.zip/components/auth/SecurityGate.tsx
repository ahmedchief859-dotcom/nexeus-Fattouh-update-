'use client'

import { FormEvent, ReactNode, useEffect, useState } from 'react'

const ACCESS_PIN = '117007#'

export function SecurityGate({ children }: { children: ReactNode }) {
  const [pin, setPin] = useState('')
  const [unlocked, setUnlocked] = useState(false)
  const [error, setError] = useState('')
  const [failedAttempts, setFailedAttempts] = useState(0)
  const [locked, setLocked] = useState(false)
  useEffect(() => {
    setUnlocked(sessionStorage.getItem('nexora-gate-unlocked') === 'true')
    const storedAttempts = Number(sessionStorage.getItem('nexora-gate-failed-attempts') ?? 0)
    if (storedAttempts >= 3) { setFailedAttempts(3); setLocked(true) }
  }, [])

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (locked) return
    if (pin === ACCESS_PIN) {
      sessionStorage.setItem('nexora-gate-unlocked', 'true')
      sessionStorage.removeItem('nexora-gate-failed-attempts')
      setUnlocked(true)
      setError('')
      return
    }
    const attempts = failedAttempts + 1
    sessionStorage.setItem('nexora-gate-failed-attempts', String(attempts))
    setFailedAttempts(attempts)
    setPin('')
    if (attempts >= 3) {
      setLocked(true)
      setError('Access denied. This workspace is locked after three failed attempts.')
    } else {
      setError(`Access denied. ${3 - attempts} attempt${3 - attempts === 1 ? '' : 's'} remaining.`)
    }
  }

  if (unlocked) return <>{children}</>

  return (
    <main className="auth-shell">
      <section className="auth-card" aria-labelledby="security-gate-title">
        <div className="brand-mark">N</div>
        <p className="eyebrow">NEXORA SECURE ACCESS</p>
        <h1 id="security-gate-title">Verify workspace access</h1>
        <p className="auth-subtitle">Enter the authorized security PIN before continuing to the identity portal.</p>
        <form onSubmit={submit} className="auth-form">
          <label>
            Security PIN
            <input
              autoFocus
              inputMode="text"
              type="password"
              value={pin}
              onChange={(event) => setPin(event.target.value)}
              placeholder={locked ? 'Workspace locked' : 'Enter authorized PIN'}
              aria-invalid={Boolean(error)}
              disabled={locked}
              required
            />
          </label>
          {error && <p className="auth-error" role="alert">{error}</p>}
          <button type="submit">Continue securely</button>
        </form>
        <p className="auth-footer">Authorized personnel only. All access attempts are monitored.</p>
      </section>
    </main>
  )
}
